/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_1_a_6;

/**
 *
 * @author user
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pessoa p1 = new Pessoa();
        
        InOut.MsgDeInforma("Informações da pessoa", "Nome: " +p1.getNome());
        InOut.MsgDeInforma("Informações da pessoa", "Endereço: " +p1.getEndereco());
        InOut.MsgDeInforma("Informações da pessoa", "Telefone: " +p1.getTelefone());
        
        Fornecedor f1 = new Fornecedor();
        
        InOut.MsgDeInforma("Informações do fornecedor", "Nome: " +f1.getNome());
        InOut.MsgDeInforma("Informações do fornecedor", "Endereço: : " +f1.getEndereco());
        InOut.MsgDeInforma("Informações do fornecedor", "Telefone: " +f1.getTelefone());
        InOut.MsgDeInforma("Informações do fornecedor", "Saldo atual: " +f1.obterSaldo());
        
        Empregado e1 = new Empregado();
        
        InOut.MsgDeInforma("Informações do empregado", "Nome: " +e1.getNome());
        InOut.MsgDeInforma("Informações do empregado", "Endereço: " +e1.getEndereco());
        InOut.MsgDeInforma("Informações do empregado", "Telefone: " +e1.getTelefone());
        InOut.MsgDeInforma("Informações do empregado", "Codigo do setor: " +e1.getCodigoSetor());
        InOut.MsgDeInforma("Informações do empregado", "Saldo atual: " +e1.calcularSalario());
        
        Administrador a1 = new Administrador();
        
        InOut.MsgDeInforma("Informações do administrador", "Nome: " +a1.getNome());
        InOut.MsgDeInforma("Informações do administrador", "Endereço: " +a1.getEndereco());
        InOut.MsgDeInforma("Informações do administrador", "Telefone: " +a1.getTelefone());
        InOut.MsgDeInforma("Informações do administrador", "Codigo do setor: " +a1.getCodigoSetor());
        InOut.MsgDeInforma("Informações do administrador", "Saldo atual: " +a1.calcularSalario());
        
        Operario o1 = new Operario();
        
        InOut.MsgDeInforma("Informações do operario", "Nome: " +o1.getNome());
        InOut.MsgDeInforma("Informações do operario", "Endereço: " +o1.getEndereco());
        InOut.MsgDeInforma("Informações do operario", "Telefone: " +o1.getTelefone());
        InOut.MsgDeInforma("Informações do operario", "Codigo do setor: " +o1.getCodigoSetor());
        InOut.MsgDeInforma("Informações do operario", "Saldo atual: " +o1.calcularSalario());
        
        Vendedor v1 = new Vendedor();
        
        InOut.MsgDeInforma("Informações do vendedor", "Nome: " +v1.getNome());
        InOut.MsgDeInforma("Informações do vendedor", "Endereço: " +v1.getEndereco());
        InOut.MsgDeInforma("Informações do vendedor", "Telefone: " +v1.getTelefone());
        InOut.MsgDeInforma("Informações do vendedor", "Codigo do setor: " +v1.getCodigoSetor());
        InOut.MsgDeInforma("Informações do vendedor", "Saldo atual: " +v1.calcularSalario());
    }
    
}
