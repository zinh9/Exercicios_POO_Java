/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double [] notas = new double[10];
        int [] matriculas = new int[10];
        
        // Adicionando valores de notas e matriculas
        for(int i = 0; i < matriculas.length; i++){
            matriculas[i] = InOut.leInt((i + 1) +") Digite a matricula: ");
            notas[i] = InOut.leDouble((i + 1) +"Digite a nota: ");
        }
        
        // Fazendo a média das notas
        double soma = 0;
        
        for(int i = 0; i < notas.length; i++){
            soma += notas[i];
        }
        
        double media = soma / notas.length;
        
        InOut.MsgDeInforma("Média das notas", "A média das notas é: " +media);
        
        // Notas acima e abaixo da média
        int acimaMedia = 0;
        int abaixoMedia = 0;
        
        for(int i = 0; i < notas.length; i++){
            if(notas[i] > media){
                acimaMedia++;
            }else{
                abaixoMedia++;
            }
        }
        
        InOut.MsgDeInforma("Média das notas", acimaMedia +" estão acima da média\n" +abaixoMedia +"estão abaixo da média");

        // Matriculados com maior e menor nota
        for(int i = 0; i < acimaMedia; i++){
            if(notas[i] > media){
                InOut.MsgDeInforma("Maiores notas", "Aluno: " +matriculas[i] +"Nota: " +notas[i]);
            }else if(notas[i] < media){
                InOut.MsgDeInforma("Menores notas", "Aluno: " +matriculas[i] +"Nota: " +notas[i]);
            }
        }
    }
}
