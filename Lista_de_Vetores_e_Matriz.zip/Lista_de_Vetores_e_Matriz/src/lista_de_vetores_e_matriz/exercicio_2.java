/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor = new int[10];
        int aux, i, j;
        
        for(i = 0; i < vetor.length; i++){
            vetor[i] = InOut.leInt("Digite o valor do indice " +i +" do vetor: ");
        }
        
        for(i = 0; i < (vetor.length - 1); i++){
            for(j = (i + 1); j < vetor.length; j++){
                if(vetor[i] > vetor[j]){
                    aux = vetor[i];
                    vetor[i] = vetor[j];
                    vetor[j] = aux;
                }
            }
        }
        
        for(i = 0; i < vetor.length; i++){
            System.out.print(vetor[i] +"\t");
        }
    }
    
}
