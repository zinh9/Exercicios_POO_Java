/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_1_a_6;

/**
 *
 * @author user
 */
public class Pessoa {
    private String nome;
    private String endereco;
    private String telefone;
    
    Pessoa(){
        setNome(InOut.leString("Informe o seu nome: "));
        setEndereco(InOut.leString("Informe o seu endereço: "));
        setTelefone(InOut.leString("Informe o seu telefone: "));
    }
    
    Pessoa(String nome, String endereco, String telefone){
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }


    Pessoa(String nome, String endereco){
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = "";
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}

class Fornecedor extends Pessoa{
    private double valorCredito;
    private double valorDivida;
    
    Fornecedor(){
        setValorCredito(InOut.leDouble("Informe o valor de credito: "));
        setValorDivida(InOut.leDouble("Informe o valor da divida: "));
    }
    
    Fornecedor(String nome, String endereco, String telefone){
        super(nome, endereco, telefone);
        this.valorCredito = 0.0;
        this.valorDivida = 0.0;
    }
    
    Fornecedor(String nome, String endereco, String telefone, double valorCredito, double valorDivida){
        super(nome, endereco, telefone);
        this.valorCredito = valorCredito;
        this.valorDivida = valorDivida;
    }

    public double getValorCredito() {
        return valorCredito;
    }

    public double getValorDivida() {
        return valorDivida;
    }

    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }

    public void setValorDivida(double valorDivida) {
        this.valorDivida = valorDivida;
    }
    
    public double obterSaldo(){
        double saldo = 0;
        
        if(valorCredito > 0 && valorDivida > 0){
            saldo = (valorCredito - valorDivida);
        }else{
            InOut.MsgDeErro("Informação do saldo", "Saldo insuficiente");
        }
        
        return saldo;
    }
}

class Empregado extends Pessoa{
    private int codigoSetor;
    private double salarioBase;
    private double imposto;
    
    Empregado(){
        super();
        setCodigoSetor(InOut.leInt("Informe o codigo do setor: "));
        setSalarioBase(InOut.leDouble("Informe o salario base: "));
        setImposto(InOut.leDouble("Informe o imposto: "));
    }

    public int getCodigoSetor() {
        return codigoSetor;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public double getImposto() {
        return imposto;
    }

    public void setCodigoSetor(int codigoSetor) {
        this.codigoSetor = codigoSetor;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public void setImposto(double imposto) {
        this.imposto = imposto;
    }
    
    public double calcularSalario(){
        double salario = 0;
        
        if(imposto > 1){
            salario = salarioBase - (salarioBase * (imposto / 100));
        }else{
            salario = salarioBase - (salarioBase * imposto);
        }
        
        return salario;
    }
}

class Administrador extends Empregado{
    private double ajudaDeCusto;
    
    Administrador(){
        super();
        setAjudaDeCusto(InOut.leDouble("Informe o valor da ajuda de custo: "));
    }

    public double getAjudaDeCusto() {
        return ajudaDeCusto;
    }

    public void setAjudaDeCusto(double ajudaDeCusto) {
        this.ajudaDeCusto = ajudaDeCusto;
    }
    
    @Override
    public double calcularSalario(){
        return super.calcularSalario() + ajudaDeCusto;
    }
}

class Operario extends Empregado{
    private double valorProducao;
    private double comissao;
    
    Operario(){
        super();
        setValorProducao(InOut.leDouble("Informe o valor da produção: "));
        setComissao(InOut.leDouble("Informe o valor da comissão: "));
    }

    public double getValorProducao() {
        return valorProducao;
    }

    public double getComissao() {
        return comissao;
    }

    public void setValorProducao(double valorProducao) {
        this.valorProducao = valorProducao;
    }

    public void setComissao(double comissao) {
        if(comissao > 1){
            this.comissao = valorProducao * (comissao / 100);
        }else{
            this.comissao = comissao * valorProducao;
        }
    }
    
    @Override
    public double calcularSalario(){
        return super.calcularSalario() + comissao;
    }
}

class Vendedor extends Empregado{
    private double valorVendas;
    private double comissao;
    
    Vendedor(){
        super();
        setValorVendas(InOut.leDouble("Informe o valor das vendas: "));
        setComissao(InOut.leDouble("Informe o valor da comissão: "));
    }

    public double getValorVendas() {
        return valorVendas;
    }

    public double getComissao() {
        return comissao;
    }

    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public void setComissao(double comissao) {
        if(comissao > 1){
            this.comissao = valorVendas * (comissao / 100);
        }else{
            this.comissao = comissao * valorVendas;
        }
    }
    
    @Override
    public double calcularSalario(){
        return super.calcularSalario() + comissao;
    }
}