/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] numeros = {
            57, 23, 92, 10, 35, 48, 77, 12, 63, 41,
            29, 84, 16, 53, 20, 78, 46, 88, 5, 37,
            61, 99, 74, 18, 67, 82, 45, 30, 96, 14,
            69, 22, 72, 38, 55, 9, 80, 42, 87, 26,
            65, 94, 52, 7, 34, 71, 50, 33, 89, 68
        };
        
        int index = 0, maior = numeros[0];
        
        for(int i = 1; i < (numeros.length - 1); i++){
            if(numeros[i] > maior){
                maior = numeros[i];
                index = i;
            }
        }
        
        InOut.MsgDeInforma("Maior e Index", "O maior elemento é: " +maior +"\nIndice: " +index);
    }
    
}
