/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] matriz = {
            {1, 2, 3, 4},
            {0, 5, 6, 7},
            {0, 0, 8, 9},
            {0, 0, 0, 10}
        };
        
        int i, j, soma = 0;
        
        for(i = 0; i < matriz.length; i++){
            for(j = (i + 1); j < matriz.length; j++){
                soma += matriz[i][j];
            }
        }
        
        InOut.MsgDeInforma("Informação", "A soma dos elementos da matriz superior é: " +soma);
    }
    
}
