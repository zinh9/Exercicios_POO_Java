/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

import static lista_de_vetores_e_matriz.InOut.leInt;

/**
 *
 * @author user
 */
public class exercicio_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor1 = new int[5];
        int [] vetor2 = new int[5];
        int [] vetor_soma = new int[5];
        
        for(int i = 0; i < vetor1.length; i++){
            vetor1[i] = InOut.leInt("Digite o valor do indice " +i +" do vetor 1: ");
            vetor2[i] = InOut.leInt("Digite o valor do indice " +i +" do vetor 2: ");
        }
        
        int soma = 0;
        
        for(int i = 0; i < vetor1.length; i++){
            vetor_soma[i] = vetor1[i] + vetor2[i];
            System.out.print(vetor_soma[i] +"\t");
        }
    }
    
}
