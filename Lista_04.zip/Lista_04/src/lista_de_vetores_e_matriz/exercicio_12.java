/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] matriz = {
            {1, -4, -9},
            {6, 2, 18},
            {5, 3, 11}
        };
        
        int somaLinha3 = calcularLinha3(matriz, 2);
        int somaColuna2 = calcularColuna2(matriz, 1);
        int somaDiagonalP = calcularDiagonalP(matriz);
        int somaDiagonalS = calcularDiagonalS(matriz);
        int somaElementos  =calcularTodosElementos(matriz);
        
        System.out.println(somaLinha3);
        System.out.println(somaColuna2);
        System.out.println(somaDiagonalP);
        System.out.println(somaDiagonalS);
        System.out.println(somaElementos);
    }
    // Função para calcular todos os elementos da 3 linha
    public static int calcularLinha3(int [][] matriz, int linha){
        int i, soma = 0;
        
        for(i = 0; i < matriz[linha].length; i++){
            soma += matriz[linha][i];
        }
        
        return soma;
    }
    // Função para calcular todos os elementos da 2 coluna
    public static int calcularColuna2(int [][] matriz, int coluna){
        int i, soma = 0;
        
        for(i = 0; i <  matriz.length; i++){
            soma += matriz[i][coluna];
        }
        
        return soma;
    }
    // Função para calcular todos os elementos da diagonal principal
    public static int calcularDiagonalP(int [][] matriz){
        int i, soma = 0;
        
        for(i = 0; i < matriz.length; i++){
            soma += matriz[i][i];
        }
        
        return soma;
    }
    // Função para calcular todos os elementos da diagonal secundaria
    public static int calcularDiagonalS(int [][] matriz){
        int i, soma = 0;
        
        for(i = 0; i < matriz.length; i++){
            soma += matriz[i][matriz.length - 1 - i];
        }
        
        return soma;
    }
    // Função para calcular todos os elementos presentes na matriz
    public static int calcularTodosElementos(int [][] matriz){
        int i, j, l, soma = 0;
        
        for(i = 0; i < matriz.length; i++){
            for(j = 0; j < matriz.length; j++){
                soma += matriz[i][j];
            }
        }
        
        return soma;
    }
}
