/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double [][] notasTurma = new double[5][5];
        double [] media = new double[5];
        
        // Inserindo os dados
        for(int i = 0; i < notasTurma.length; i++){
            for(int j = 0; j < notasTurma[i].length; j++){
                notasTurma[i][j] = InOut.leDouble("Insira a nota " +(j + 1) +" do aluno " +i +": ");
            }
        }
        
        // Fazendo a média das notas de cada aluno
        for(int i = 0; i < media.length; i++){
            double soma = 0;
            
            for(int j = 0; j < notasTurma[i].length; j++){
                soma += notasTurma[i][j];
            }
            
            media[i] = soma / notasTurma[i].length;
        }
        
        // Fazendo a média geral da turma
        double mediaGeral = 0;
        
        for(int i = 0; i < media.length; i++){
            mediaGeral += media[i];
        }
        
        mediaGeral /= media.length;
        
        // Imprimindo layout
        System.out.println("Num. Aluno\t\t\tNotas\t\t\t\t\tMedia Aluno");
        
        for(int i = 0; i < notasTurma.length; i++){
            System.out.print(i +"\t\t");
            
            for(int j = 0; j < notasTurma[i].length; j++){
                System.out.print(notasTurma[i][j] +"\t");
            }
            
            System.out.println("\t\t" +media[i]);
        }
        
        System.out.println("Média geral da turma: " +mediaGeral);
    }
    
}
