/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] numeros = new int[40];
        
        for(int i = 0; i < numeros.length; i++){
            numeros[i] = (i + 1);
        }
        
        int i = 0, j = 1, aux = 0;
        
        while(j < numeros.length){
            aux = numeros[j];
            numeros[j] = numeros[i];
            numeros[i] = aux;
            
            i++;
            j++;
        }
        
        System.out.println(numeros[numeros.length - 1] +"\t");
    }
    
}
