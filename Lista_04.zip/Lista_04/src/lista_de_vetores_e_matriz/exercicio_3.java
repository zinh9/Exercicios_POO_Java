/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor = new int[10];
        
        for(int i = 0; i < vetor.length; i++){
            vetor[i] = InOut.leInt("Digite o valor do indice " +i +" do vetor: ");
        }
        
        for(int i = 0; i < vetor.length; i++){
            if(vetor[i] % 6 == 0){
                System.out.print(vetor[i] +"\t");
            }
        }
    }
    
}
