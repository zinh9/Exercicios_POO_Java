/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [][] matriz = {
            {1, 0, 0, 0, 0, 0, 0},
            {2, 3, 0, 0, 0, 0, 0},
            {4, 5, 6, 0, 0, 0, 0},
            {7, 8, 9, 10, 0, 0, 0},
            {11, 12, 13, 14, 0, 0, 0},
            {15, 16, 17, 18, 19, 0, 0},
            {20, 21, 22, 23, 24, 25, 0}
        };
        
        for(int i = 1; i < matriz.length; i++){
            for(int j = 0; j < matriz[i].length; j++){
                if(matriz[i][j] != 0){
                    System.out.print(matriz[i][j] +"\t");
                }else{
                    break;
                }
            }
            System.out.println();
        }
    }
    
}
