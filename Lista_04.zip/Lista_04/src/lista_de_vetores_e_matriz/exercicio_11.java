/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double [] numeros = {
            10.5, 7.2, 15.8, 3.9, 20.6,
            12.3, 8.7, 18.4, 5.6, 16.9,
            9.2, 14.1, 6.8, 11.0, 4.3,
            19.7, 13.6, 2.5, 17.2, 1.8
        };
        
        double maior = numeros[0], menor = numeros[0];
        int i, j, indexMaior = 0, indexMenor = 0;
        
        // Identificar maior elemento
        for(i = 1; i < numeros.length; i++){
            if(numeros[i] > maior){
                maior = numeros[i];
                indexMaior = i;
            }
        }
        
        // Identificar menor elemento
        for(i = 1; i < numeros.length; i++){
            if(numeros[i] < menor){
                menor = numeros[i];
                indexMenor = i;
            }
        }
        
        double diferenca = maior - menor;
        
        InOut.MsgDeInforma("Informação", "O maior elemento é: " +maior +"\nIndice: " +indexMaior 
                +"\n\nO menor elemento é: " +menor +"\nIndice: " +indexMenor +"\n\nA diferença dos elementos: " +diferenca);
    }
    
}
