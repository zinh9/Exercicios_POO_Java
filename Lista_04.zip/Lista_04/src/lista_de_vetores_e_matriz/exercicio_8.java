/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista_de_vetores_e_matriz;

/**
 *
 * @author user
 */
public class exercicio_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] vetor = {3, 6, 1, 9, 5, 8, 3, 6, 4, 9, 13, 15};
        
        int x = InOut.leInt("Digite a posição de X: ");
        int y = InOut.leInt("Digite a posição de Y: ");
        int soma = vetor[x] + vetor[y];
        
        InOut.MsgDeInforma("Soma", "A soma dos valores de X e Y encontrados é: " +soma);
    }
    
}
