/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_3;

/**
 *
 * @author user
 */
public class PesoIdeal {
    double peso;
    double altura;
    String sexo;
    boolean verifica;
    
    public boolean verificaDados(){
        if (peso >= 2 && peso <= 200 && altura >= 1 && altura <= 2.5 && (sexo == "F" || sexo == "M")){
            verifica = true;
        }else{
            verifica = false;
        }
        
        return verifica;
    }
    
    public double calculaPesoIdeal(){
        double pesoIdeal = 0;
        
        if (verifica == true){
            if (sexo == "M"){
                pesoIdeal = (62.1 * altura) - 47.7;
            }
            else if(sexo == "H"){
                pesoIdeal = (72.7 * altura) - 58;
            }
        }else{
            System.out.println("Dados invalidos!");
        }
        
        return pesoIdeal;
    }
}
