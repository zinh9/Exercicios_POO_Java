/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_3;

/**
 *
 * @author user
 */
public class main_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PesoIdeal meuP = new PesoIdeal();
        
        meuP.altura = 1.70;
        meuP.peso = 60;
        meuP.sexo = "M";
        
        System.out.println("Dados: " +meuP.verificaDados());
        System.out.println("Meu peso ideal eh: " +meuP.calculaPesoIdeal());
    }
    
}
