/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_2;

/**
 *
 * @author user
 */
public class main_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Triangulo meuT = new Triangulo();
        
        meuT.ladoA = 3;
        meuT.ladoB = 4;
        meuT.ladoC = 5;
        
        System.out.println(meuT.verificaTriangulo());
        System.out.println("A area do meu triangulo eh: " +meuT.calculaArea());
    }
    
}
