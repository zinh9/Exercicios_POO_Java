/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_2;

import static java.lang.Math.sqrt;

/**
 *
 * @author user
 */
public class Triangulo {
    double ladoA;
    double ladoB;
    double ladoC;
    boolean verifica;
    
    public boolean verificaTriangulo(){
        if (ladoA < (ladoB + ladoC) && ladoB < (ladoA + ladoC) &&  ladoC < (ladoA + ladoB)){
            verifica = true;
        }else{
            verifica = false;
        }
        
        return verifica;
    }
    
    public double calculaArea(){
        double area;
        double s;
        
        if (verifica == true){
            s = (ladoA + ladoB + ladoC) / 2;
            area = sqrt(s * (s - ladoA) * (s - ladoB) * (s - ladoC));
        }else{
            System.out.println("Nao eh possivel calcular a area do triangulo!");
            area = 0;
        }
        
        return area;
    }
}
