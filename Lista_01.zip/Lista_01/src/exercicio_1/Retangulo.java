/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_1;

/**
 *
 * @author user
 */
public class Retangulo {
    double base;
    double altura;
    boolean verifica;
    
    public boolean verificaRetangulo(){
        if(base != altura){
            verifica = true;
        }else{
            verifica = false;
        }
        
        return verifica;
    }
    
    public double calculaArea(){
        double area;
        
        if(verifica == true){
            area = base * altura;
            return area;
        }else{
            System.out.println("Nao eh possivel calcular a area do retangulo");
            area = 0;
        }
        
        return area;
    }
    
    public double calculaPerimetro(){
        double p = 2 * (base + altura);
        
        return p;
    }
}
