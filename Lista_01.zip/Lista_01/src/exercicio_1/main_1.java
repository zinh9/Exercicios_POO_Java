/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_1;

/**
 *
 * @author user
 */
public class main_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Retangulo meuR = new Retangulo();
        meuR.altura = 10;
        meuR.base = 10;
        
        System.out.println(meuR.verificaRetangulo());
        System.out.println("A area do meu retangulo eh: " +meuR.calculaArea());
        System.out.println("O perimetro do meu retangulo eh: " +meuR.calculaPerimetro());
    }
    
}
