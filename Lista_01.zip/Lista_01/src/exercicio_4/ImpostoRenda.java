/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_4;

/**
 *
 * @author user
 */
public class ImpostoRenda {
    double valSalBruto;
    double valSalLiquido;
    double valDesconto;
    boolean verifica;
    
    public boolean verificaDados(){
        if (valSalBruto > 0){
            verifica = true;
        }else{
            verifica = false;
        }
        
        return verifica;
    }
    
    public void calculaImposto(){
        double imposto;
        
        if (verifica == true){
            if (valSalBruto <= 1903.98){
                System.out.println("Voce nao paga imposto!");
                
            } else if (valSalBruto >= 1903.98 && valSalBruto <= 2826.65){
                imposto = (valSalBruto * 0.075) - 142.8;
                System.out.println("Valor do imposto: " +imposto);
                
            } else if (valSalBruto >= 2826.66 && valSalBruto <= 3751.05){
                imposto = (valSalBruto * 0.15) - 354.8;
                System.out.println("Valor do imposto: " +imposto);
                
            } else if (valSalBruto >= 3751.06 && valSalBruto <= 4664.68){
                imposto = (valSalBruto * 0.225) - 636.13;
                System.out.println("Valor do imposto: " +imposto);
                
            } else{
                imposto = (valSalBruto * 0.275) - 869.36;
                System.out.println("Valor do imposto: " +imposto);
                
            }
        }else{
            System.out.println("Dados invalidos!");
        }
    }
}
