/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_4;

/**
 *
 * @author user
 */
public class main_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ImpostoRenda meuI = new ImpostoRenda();
        
        meuI.valSalBruto = 5000;
        meuI.valSalLiquido = 2910;
        meuI.valDesconto = 0.7;
        
        System.out.println("Dados: " +meuI.verificaDados());
        meuI.calculaImposto();
    }
    
}
