/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_1;

/**
 *
 * @author user
 */
public class main_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario meuF = new Funcionario();
                
        meuF.setCpf(InOut.leInt("Informe o CPF: "));
        meuF.setNome(InOut.leString("Informe o nome: "));
        meuF.setHorasTrab(InOut.leDouble("Informe as horas trabalhadas: "));
        meuF.setValorHora(InOut.leDouble("Informe o valor por hora: "));
        meuF.setHoraExt(InOut.leDouble("Informe a hora extra: "));
        
        InOut.MsgDeInforma("Informações", "CPF: " +meuF.getCpf());
        InOut.MsgDeInforma("Informações", "Funcionario: " +meuF.getNome());
        InOut.MsgDeInforma("Informações", "Horas Trabalhadas: " +meuF.getHorasTrab());
        InOut.MsgDeInforma("Informações", "Hora extra: " +meuF.getHoraExt());
        InOut.MsgDeInforma("Informações", "Salario: " +meuF.calculaSalario());
    }
    
}
