/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_1;

/**
 *
 * @author user
 */
public class Funcionario {
    private int cpf;
    private String nome;
    private double horasTrab;
    private double valorHora;
    private double horaExt;
    
    Funcionario(){
        cpf = 0;
        nome = "";
        horasTrab = 0;
        valorHora = 0;
        horaExt = 0;
    }

    public int getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public double getHorasTrab() {
        return horasTrab;
    }

    public double getValorHora() {
        return valorHora;
    }

    public double getHoraExt() {
        return horaExt;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setHorasTrab(double horasTrab) {
        this.horasTrab = horasTrab;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    public void setHoraExt(double horaExt) {
        this.horaExt = horaExt;
    }
    
    public double calculaSalario(){
        double salario = 0;
        
        if (horasTrab > 0 && valorHora > 0 && horaExt > 0){
            salario = valorHora * (horasTrab + horaExt);
        } else{
            System.out.println("Nao foi possivel calcular seu salario por erro de dados!");
        }
        
        return salario;
    }
}
