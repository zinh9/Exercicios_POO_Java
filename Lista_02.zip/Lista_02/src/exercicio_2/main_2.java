/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_2;

import exercicio_1.InOut;

/**
 *
 * @author user
 */
public class main_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ContaBancaria meuB = new ContaBancaria();
        
        meuB.setNumero(InOut.leInt("Informe o numero do banco: "));
        meuB.setAgencia(InOut.leInt("Informe a agencia do banco: "));
        meuB.setCliente(InOut.leString("Informe o nome: "));
        meuB.setSaldo(InOut.leDouble("Informe o saldo: "));
        meuB.setChequeEspecial(InOut.leDouble("Informe o cheque especial: "));
        meuB.sacar(InOut.leDouble("Informe a retirada: "));
        meuB.depositar(InOut.leDouble("Informe o deposito: "));
        
        InOut.MsgDeInforma("Informações", "Saldo atual: " +meuB.verificarSaldo());
        InOut.MsgDeInforma("Informações", "Conta: " +meuB.getNumero());
        InOut.MsgDeInforma("Informações", "Agencia: " +meuB.getAgencia());
        InOut.MsgDeInforma("Informações", "Cliente: " +meuB.getCliente());
        InOut.MsgDeInforma("Informações", "Saldo: " +meuB.getSaldo());
        InOut.MsgDeInforma("Informações", "Cheque Especial: " +meuB.getChequeEspecial());
    }
    
}
