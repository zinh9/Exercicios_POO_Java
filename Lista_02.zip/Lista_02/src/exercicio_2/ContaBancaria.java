/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_2;

/**
 *
 * @author user
 */
public class ContaBancaria {
    private int numero;
    private int agencia;
    private String cliente;
    private double saldo;
    private double chequeEspecial;
    
    ContaBancaria(){
        numero = 0;
        agencia = 0;
        cliente = "";
        saldo = 0;
        chequeEspecial = 0;
    }

    public int getNumero() {
        return numero;
    }

    public int getAgencia() {
        return agencia;
    }

    public String getCliente() {
        return cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getChequeEspecial() {
        return chequeEspecial;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setChequeEspecial(double chequeEspecial) {
        this.chequeEspecial = chequeEspecial;
    }
    
    public void sacar(double retirada){
        if(retirada > saldo){
            chequeEspecial -= retirada - saldo;
            saldo = 0;
        }else{
            this.saldo -= retirada;
        }
    }
    
    public void depositar(double deposito){
        this.saldo += deposito;
    }
    
    public double verificarSaldo(){
        return saldo + chequeEspecial;
    }
}
